#!/bin/bash
find * -name '*.sh' | rev | cut -d '/' -f1 | cut -c 4- | rev
