#!/bin/bash
find . | wc -l | tr -d ' [:blank:] '
