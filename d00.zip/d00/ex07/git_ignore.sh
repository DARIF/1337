#!/bin/bash
git check-ignore *
